package com.chamelaeon.dicebot;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class Personality {
	
	/** The exception texts, mapped by key. */
	private final Map<String, String> exceptionTexts;
	
	public Personality() {
		this.exceptionTexts = new HashMap<String, String>();
		exceptionTexts.put("LessThanOneGroup", "Rolling fewer than 1 groups may cause pan-dimensional collapse and a great deal of wibbly. Let's not do it.");
		exceptionTexts.put("Roll0Dice", "It's come to my attention you're rolling 0 dice. I'm pleased to inform you that you've rolled NaN. Good day.");
		exceptionTexts.put("Roll0Sides", "My god, man, you've rolled a die with no sides! We have to act quickly! You stay put and hold this umbrella, I'll go get the lemurs.");
		exceptionTexts.put("OneSidedDice", "Well, you rolled %d one-sided dice, so you get a %d. Also, I've been authorized to begin unethical testing with your corpse. Stand by...");
		exceptionTexts.put("KeepingLessThan1", "Keeping fewer than 1 dice isn't Zen, Dragon-san, it's madness. MADNESS, I TELL YOU!");
		exceptionTexts.put("RollLessThanKeep", "Rolling fewer dice than you're keeping? This is the perfect time to try out my new anti-cheating Bushido Bot!");
		exceptionTexts.put("BadCommand", "Somehow, in the milliseconds between asking me to do something and now, I've forgotten how to do the thing you asked! I've even forgotten what it was!");
		exceptionTexts.put("CannotSatisfyRerollSingleDie", "It seems that the reroll condition %d can't be satisfied by a die with %d sides. I suggest a rousing game of Candyland instead.");
		exceptionTexts.put("CannotSatisfyRerollMultipleDice", "It seems that the reroll condition %d can't be satisfied by %d dice with %d sides. I suggest a rousing game of Candyland instead.");
		exceptionTexts.put("InfiniteExplosion", "Make a reservation at Milliways, since the infinitely exploding dice on that roll won't be done until the end of the universe.");
	}
	
	/**
	 * Gets the user-facing {@link InputException} represented by the key.  
	 * @param exceptionKey The exception's individual key.
	 * @return the exception to throw up to where a user can see it.
	 */
	public InputException getException(String exceptionKey, Object... params) {
		return new InputException(String.format(exceptionTexts.get(exceptionKey), params));
	}
	
	/**
	 * Picks a random critical failure line from the available selection.
	 * @param random The random to use.
	 * @return the selected critical failure line.
	 */
	public String chooseCriticalFailureLine(Random random) {
		if (random.nextBoolean()) {
			return "Excellent! We've been looking for a test subject. Hold on to this horseshoe and penny while I alert the Leprechaun Entrapment Brigade, we'll have you fixed in no time...";
		} else {
			return "We've developed an implantable luck generator you could try, if you aren't using that liver...";
		}
	}
	
	/**
	 * Gets a status message.
	 * @return the status.
	 */
	public String getStatus() {
		return "Status: Not A Walrus!";
	}
	
	/**
	 * Picks a random critical success line from the available selection.
	 * @param random The random to use.
	 * @return the selected critical success line.
	 */
	public String chooseCriticalSuccessLine(Random random) {
		if (random.nextBoolean()) {
			return "Ah, then this IS the reality where you're kicking ass. My apologies, I'll amend my notes.";
		} else {
			return "May I borrow your pituitary gland for a moment? You'll get it back good as new, I promise!";
		}
	}
}
