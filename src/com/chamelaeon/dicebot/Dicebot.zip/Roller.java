package com.chamelaeon.dicebot;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;

import com.chamelaeon.dicebot.Behavior.Explosion;
import com.chamelaeon.dicebot.Behavior.L5RExplosion;
import com.chamelaeon.dicebot.Behavior.Reroll;
import com.chamelaeon.dicebot.Roll.GroupResult;

/** Abstract class describing all types of rollers. */
public abstract class Roller implements LineConsumer {
	/** The random to use. */
	protected final Random random;
	/** The object to use to track statistics. */ 
	private final Statistics statistics;
	/** The personality object containing quotes (if necessary). */
	private final Personality personality;
	
	/** Protected constructor. */
	protected Roller(Statistics statistics, Personality personality) {
		 random = new Random();
		 this.statistics = statistics;
		 this.personality = personality;
	}
	/** Gets the {@link Statistics} object. */
	protected Statistics getStatistics() {
		return statistics;
	}
	
	/** Gets the {@link Personality} object. */
	protected Personality getPersonality() {
		return personality;
	}

	@Override
	public String consume(Matcher matcher, String source, String user) throws InputException {
			int count = matcher.groupCount();
			String[] parts = new String[count+1];
			for (int i = 0; i <= count; i++) {
				String group = matcher.group(i);
				if (null != group) {
					group = group.trim();
				}
				parts[i] = group;
			}
			return assembleRoll(parts, user);
	}
	
	/**
	 * Parses the groups portion of the roll and limits it to the range [1, 10].
	 * @param groupString The groups string to parse.
	 * @return the number of groups.
	 * @throws InputException if the groups could not be parsed or is less than 1.
	 */
	protected short parseGroups(String groupString) throws InputException {
		if (null != groupString) {
			short parsedGroups = Utils.parseShort(groupString);
			if (parsedGroups >= 1) {
				if (parsedGroups > 10) {
					return 10;
				} else {
					return parsedGroups;
				}
			} else {
				throw getPersonality().getException("LessThanOneGroup");
			}
		} else {
			return 1;
		}
	}
	
	/**
	 * Prints the group count to a string, suppressing if the value is 1.
	 * @param groups The group count that was rolled.
	 * @return the string.
	 */
	protected String getGroupCountString(int groupCount) {
		String ret = "";
		if (groupCount > 1) {
			ret = ret + groupCount + " ";
		}
		return ret;
	}
	
	/**
	 * Performs the actual roll, given all the matched groups from the parsing regexp.
	 * @param parts The parts to parse.
	 * @param user The user who made the roll.
	 * @return the result of the roll.
	 * @throws InputException if the input has issues.
	 */
	protected abstract String assembleRoll(String[] parts, String user) throws InputException;
	
	/**
	 * Gets the name of this rolling system.
	 * @return the style of the roller.
	 */
	public abstract String getName();
	
	/**
	 * Gets the brief description of the rolling system and the available options. Each string
	 * in the list will be printed as its own line." 
	 * @return the description of the roller.
	 */
	public abstract List<String> getDescription();
	
	/**
	 * Gets the regexp for this roller.
	 * @return the regexp.
	 */
	public abstract String getRegexp();
	
	/** A roller for handling standard die behavior, like "2d6" or "1d20". */
	public static class StandardRoller extends Roller {
		/**
		 * Constructor.
		 * @param statistics The statistics object for tracking statistics.
		 * @param personality The object containing the dicebot personality.
		 */
		public StandardRoller(Statistics statistics, Personality personality) {
			super(statistics, personality);
		}
		
		@Override
		public String assembleRoll(String[] parts, String user) throws InputException {
			short groupCount = parseGroups(parts[1]);
			short diceCount = Utils.parseDiceCount(parts[2]);
			short diceType = Utils.parseShort(parts[3]);
			if (diceCount < 1) {
				throw getPersonality().getException("Roll0Dice");
			} else if (diceType < 1) {
				throw getPersonality().getException("Roll0Sides");
			} else if (diceType == 1) {
				throw getPersonality().getException("OneSidedDice", diceCount, diceCount);
			}
			Reroll reroll = Behavior.parseReroll(parts[4]);
			Explosion explosion = Behavior.parseExplosion(parts[4], diceCount * diceType);
			Modifier modifier = Modifier.createModifier(parts[5]);
			
			Roll roll = new Roll(diceCount, diceCount, diceType, modifier, reroll, explosion, getPersonality());
			List<GroupResult> groups = roll.performRoll(groupCount, random, getStatistics());
				
			String behaviors = Behavior.getPrettyString(roll);
			return buildString(getGroupCountString(groupCount) + diceCount + "d" + diceType + behaviors + modifier , user, groups);
		}
		
		@Override
		public String getName() {
			return "Standard";
		}

		@Override
		public String getRegexp() {
			return "^(\\d+ )?(\\d*)d(\\d+)(b[1-9]|v(?:[1-9][0-9]?)?)?(\\+\\d+|-\\d+)?";
		}

		@Override
		public List<String> getDescription() {
			List<String> retList = new ArrayList<String>();
			retList.add("A standard dice roller, that can handle X number of dice of Y sides each, in the format XdY. (ex. 2d6).");
			retList.add("Positive or negative modifiers may be applied to affect the result (ex. 2d6-5). If rolling only one die, the initial number may be omitted (ex. d20+10).");
			retList.add("To roll additional groups of die, prefix the roll with a number then a space (ex. 10 d20+10). Modifiers will be applied to each group individually.");
			retList.add("Brutal values of 1-9 are available by adding \"b\" then a number (ex. 2d8b2+5). Vorpal is also available by appending \"v\" (ex. 2d8v+5).");
			return retList;
		}

		/**
		 * Builds the result string for the roll groups.
		 * @param groups The groups to use to build the string.
		 * @return the output string.
		 */
		private String buildString(String baseRoll, String user, List<GroupResult> groups) {
			StringBuilder response = new StringBuilder("rolls " + baseRoll + " for " + user + " and gets a natural ");
			if (groups.size() > 1) {
				response.append("( ");
				for (GroupResult group : groups) {
					response.append(group.getNatural());
					response.append(" ");
				}
				response.append(") for a result of ( ");
				for (GroupResult group : groups) {
					response.append(group.getModified());
					response.append(" ");
				}
				response.append(").");
			} else {
				GroupResult group = groups.get(0);
				response.append(group.getNatural());
				
				if (group.isCriticalFailure() || group.isCriticalSuccess()) {
					response.append(" (");
					response.append(group.getModified());
					
					if (group.isCriticalFailure()) {
						response.append("), a CRITICAL FAILURE! \"");
						response.append(getPersonality().chooseCriticalFailureLine(random));
					} else if (group.isCriticalSuccess()) {
						response.append("), a CRITICAL SUCCESS! \"");
						response.append(getPersonality().chooseCriticalSuccessLine(random));
					}
					response.append("\"");
				} else {
					response.append(" for a result of ");
					response.append(group.getModified());
					response.append(".");
				}
			}
			return response.toString();
		}
	}
	
	/** A roller for handling L5R die behavior, like "7k3" or "2k1+2". */
	public static class L5RRoller extends Roller {
		/**
		 * Constructor.
		 * @param statistics The statistics object for tracking statistics.
		 * @param personality The object containing the dicebot personality.
		 */
		public L5RRoller(Statistics statistics, Personality personality) {
			super(statistics, personality);
		}
		
		@Override
		public String assembleRoll(String[] parts, String user) throws InputException {
			int groupCount = parseGroups(parts[1]);
			short rolled = Utils.parseShort(parts[2]);
			short kept = Utils.parseShort(parts[3]);
			Modifier modifier = Modifier.createModifier(parts[4]);
			
			Reroll reroll = Behavior.parseReroll(parts[5]);
			Explosion explosion = Behavior.parseExplosion(parts[5]);
			// If we have no special explosion use the default L5R one. 
			if (null == explosion) {
				explosion = new L5RExplosion();
			}
			Roll roll = handleRollover(new Roll(rolled, kept, (short) 10, modifier, reroll, explosion, getPersonality()));
			
			if (roll.getKept() < 1) {
				throw getPersonality().getException("KeepingLessThan1");
			} else if (roll.getRolled() < roll.getKept()) {
				throw getPersonality().getException("RollLessThanKeep");
			}
			
			List<GroupResult> groups = roll.performRoll(groupCount, random, getStatistics());
			
			String behaviors = Behavior.getPrettyString(roll);
			return buildString(getGroupCountString(groupCount) + roll.getRolled() + "k" + roll.getKept() + roll.getModifier() + behaviors, user, groups);
		}
		
		/**
		 * Handles the rollover for a group, returning a group which is guaranteed
		 * to be no more than 10k10.
		 * @param roll The group to handle rollover for.
		 * @return the rollable group.
		 * @throws InputException if the rolled-over values can't meet the reroll condition.
		 */
		private Roll handleRollover(Roll roll) throws InputException {
			if (roll.getRolled() >= 10 && roll.getKept() >= 10) {
				int rolledOverflow = roll.getRolled() - 10;
				int keptOverflow = roll.getKept() - 10;
				int overflow = rolledOverflow + keptOverflow;

				return roll.alterValues(10, 10, roll.getModifier().appendToValue(2 * overflow));
			}
			
			if (roll.getRolled() > 10) {
				int overflow = roll.getRolled() - 10;
				if (overflow > 1) {
					// We have overflow. Remove a single die and recursively call.
					return handleRollover(roll.alterValues(roll.getRolled() - 2, roll.getKept() + 1, roll.getModifier()));
				} else {
					// Strip off the extra 1 and return.
					return roll.alterValues(10, roll.getKept(), roll.getModifier());
				}
			}
				
			if (roll.getKept() > 10) {
				int overflow = roll.getKept() - 10;
				return roll.alterValues(roll.getRolled(), 10, roll.getModifier().appendToValue(2 * overflow));
			}
			
			return roll;
		}
		
		@Override
		public String getName() {
			return "L5R";
		}

		@Override
		public String getRegexp() {
			return "^(\\d+ )?(\\d+)k(\\d+)(\\+\\d+|\\-\\d+)?(me|em|e|m)?";
		}

		@Override
		public List<String> getDescription() {
			List<String> retList = new ArrayList<String>();
			retList.add("A dice roller for Legend of the Five Rings (roll/keep style), which rolls X number of d10s and keeps Y of them (ex. 5k3).");
			retList.add("Positive or negative modifiers may be applied to affect the result (ex. 5k3-5). Rolls that would \"roll over\" into static bonuses are automatically converted (ex. 13k9 into 10k10+2).");
			retList.add("To roll additional groups of die, prefix the roll with a number then a space (ex. 10 2k2-5). Modifiers will be applied to each group individually.");
			retList.add("Emphasis rolls are available by appending \"e\" to the roll (ex. 9k5e). Mastery is also available by appending \"m\" (ex. 12k3m). They may be combined (ex. 12k3+5em).");
			return retList;
		}
		
		/**
		 * Builds the result string for the roll groups.
		 * @param groups The groups to use to build the string.
		 * @return the output string.
		 */
		private String buildString(String baseRoll, String user, List<GroupResult> groups) {
			StringBuilder response = new StringBuilder("rolls " + baseRoll + " for " + user + " and gets ");
			if (groups.size() > 1) {
				response.append("( ");
				for (GroupResult group : groups) {
					response.append(group.getDice());
					response.append(" ");
				}
				response.append(") for totals of ( ");
				for (GroupResult group : groups) {
					response.append(group.getModified());
					response.append(" ");
				}
				response.append(")");
			} else {
				GroupResult group = groups.get(0);
				response.append(group.getDice());
				response.append(" for a total of ");
				response.append(group.getModified());
			}
			response.append(".");
			return response.toString();
		}
	}
}