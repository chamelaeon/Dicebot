package com.chamelaeon.dicebot;

import java.util.List;

/**
 * Utility methods common across classes.
 * @author Chamelaeon
 */
public class Utils {
	/**
	 * Safely parses a string into an short.
	 * @param shortString The string to parse.
	 * @return the parsed short.
	 * @throws InputException if the string could not be parsed.
	 */
	public static short parseShort(String shortString) throws InputException {
		try {
			return Short.parseShort(shortString);
		} catch (NumberFormatException nfe) {
			throw new InputException("Hm. I could handle " + shortString + " as a value but it would require a fundamental reordering of the universe. Hang on just an eon...");
		}
	}

	/**
	 * Parses the dice count portion of the roll and replaces NULL with 1.
	 * @param diceCountString The dice count string to parse.
	 * @return the number of dice to roll.
	 * @throws InputException if the dice rolls could not be parsed.
	 */
	public static short parseDiceCount(String diceCountString) throws InputException {
		if (null != diceCountString && !diceCountString.isEmpty()) {
			return parseShort(diceCountString);
		} else {
			return 1;
		}
	}
	
	/**
	 * Sums the first <code>count</code> values of the given list.
	 *  
	 * @param list The list to sum.
	 * @param count The first X items to sum.
	 * @return the sum.
	 */
	public static long sumFirst(List<Integer> list, int count) {
		long total = 0;
		for (int i = 0; i < count; i++) {
			total += list.get(i);
		}
		return total;
	}
}
