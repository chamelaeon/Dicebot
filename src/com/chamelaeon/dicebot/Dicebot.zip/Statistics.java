package com.chamelaeon.dicebot;

/** Data struct for storing statistics. */
public class Statistics {
	/** The number of groups that have been rolled. */
	private long groups = 0;
	/** The number of dice that have been rolled. */
	private long dice = 0;
	
	/**
	 * Gets the number of rolled groups.
	 * @return the groups.
	 */
	public long getGroups() {
		return groups;
	}
	
	/**
	 * Gets the number of rolled dice.
	 * @return the dieCount.
	 */
	public long getDice() {
		return dice;
	}
	
	/** Increments the groups count. */
	public void incrementGroups() {
		groups++;
	}
	
	/** Increments the dice count. */
	public void incrementDice() {
		dice++;
	}
	
	/**
	 * Increases the groups count by the given amount.
	 * @param modifier the amount to increase the groups by.
	 */
	public void addToGroups(int modifier) {
		groups += modifier;
	}
	
	/**
	 * Increases the dice count by the given amount.
	 * @param modifier the amount to increase the dice by.
	 */
	public void addToDice(int modifier) {
		dice += modifier;
	}
}