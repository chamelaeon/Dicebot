package com.chamelaeon.dicebot;

import java.util.Arrays;
import java.util.Scanner;

/**
 * Driver class for the dicebot.
 * @author Chamelaeon
 */
public class DicebotRunner {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {

		// Now start our bot up.
        Dicebot bot = new Dicebot("irc.sandwich.net", new Personality(), Arrays.asList("Chibi_Vernon", "Walrus_Vernon"), Arrays.asList("#digbitching"));
        bot.start();

        Scanner scanner = new Scanner(System.in);
        scanner.useDelimiter("\\n");
        while (scanner.hasNext()) {
        	String line = scanner.next();
        	
        	if (line.equals("exit") || line.equals("quit")) {
        		bot.disconnect();
        		bot.dispose();
        		System.exit(0);
        	}
        	String[] parts = line.split(" ");
        	String channel = parts[0];
        	
        	if (parts[1].equals("/me")) {
        		String message = line.substring(channel.length() + 4).trim();
        		bot.sendAction(channel, message);
        	} else {
        		String message = line.substring(channel.length()).trim();
        		bot.sendMessage(channel, message);
        	}
        }
        
	}

}
